import { useEffect } from 'react';
import Lenis from 'lenis';
import Navbar from './components/Navbar';
import ParticleCanvas from './components/ParticleCanvas';
import Hero from './components/Hero';
import Expertise from './components/Expertise';
import Works from './components/Works';
import About from './components/About';
import Team from './components/Team';
import Footer from './components/Footer';
import Preloader from './components/Preloader';
import CustomCursor from './components/CustomCursor';
import NoiseOverlay from './components/NoiseOverlay';
import { ErrorBoundary } from './components/ErrorBoundary';

export default function App() {
  useEffect(() => {
    const lenis = new Lenis();

    function raf(time: number) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);
    return () => lenis.destroy();
  }, []);

  return (
    <main className="relative bg-[#020202] text-white overflow-clip selection:bg-[#ff3300] selection:text-white">
      <ErrorBoundary>
        <Preloader />
      </ErrorBoundary>
      <CustomCursor />
      <NoiseOverlay />

      {/* 3D Background */}
      <ErrorBoundary>
        <ParticleCanvas />
      </ErrorBoundary>
      
      {/* Fixed UI */}
      <Navbar />
      
      {/* Scrolling Content overlay */}
      <div className="relative z-10 w-full">
        <Hero />
        <Expertise />
        <Works />
        <About />
        <Team />
        <Footer />
      </div>
    </main>
  );
}

